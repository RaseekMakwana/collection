# facebook-js-sdk
All the examples are related to my video series "Facebook JS SDK" on my YouTube channel @ youtube.com/c/sohaibilyas so watch the video and come back here to get the source files.
