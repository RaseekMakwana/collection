# Email Subscription Without DB
By using the code in this repository you can make an email subscription feature using PHP and jQuery without database.
