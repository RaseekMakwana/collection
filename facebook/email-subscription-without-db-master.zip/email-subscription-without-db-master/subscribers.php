<?php
if (@$_GET['code'] == '43') {

} else {
	echo "sorry...";
	exit;
}
?>
, 
